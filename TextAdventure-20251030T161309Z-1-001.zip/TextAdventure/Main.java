class Main 
{
  public static void main(String[] args) 
  {
    TextAdventure adventure = new TextAdventure();
    adventure.play();
    // new game
  }
}